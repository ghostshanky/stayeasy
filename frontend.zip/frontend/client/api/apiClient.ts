import apiClient from '../apiClient';

export default apiClient;
export * from '../apiClient';
