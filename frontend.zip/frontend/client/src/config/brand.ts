export const BRAND = {
  short: "stayeasy",
  long: "StayEasy",
  title: "StayEasy - Find your perfect PG or hostel easily.",
  tagline: "Find your perfect PG or hostel easily.",
  defaultAvatar: "/default_profile_pic.jpg",
  company: "StayEasy, Inc."
};
