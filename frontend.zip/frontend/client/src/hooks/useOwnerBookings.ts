// This file is deprecated - use useBookings hook with owner parameter instead
// Import the useOwnerBookings function from useBookings.ts
export { useOwnerBookings } from './useBookings';